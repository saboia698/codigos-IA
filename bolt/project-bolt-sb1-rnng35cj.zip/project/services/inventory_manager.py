from models.product import Product
from utils.file_handler import load_inventory, save_inventory

class InventoryManager:
    def __init__(self):
        self.inventory = self._load_products()
    
    def _load_products(self):
        data = load_inventory()
        return [Product(**item) for item in data]
    
    def add_product(self, name, quantity, price):
        new_id = len(self.inventory) + 1
        product = Product(new_id, name, quantity, price)
        self.inventory.append(product)
        self._save_changes()
        return product
    
    def update_stock(self, product_id, quantity_sold):
        for product in self.inventory:
            if product.id == product_id:
                if product.quantity >= quantity_sold:
                    product.quantity -= quantity_sold
                    self._save_changes()
                    return True
                return False
        return False
    
    def get_product(self, product_id):
        for product in self.inventory:
            if product.id == product_id:
                return product
        return None
    
    def list_products(self):
        return self.inventory
    
    def _save_changes(self):
        inventory_data = [product.to_dict() for product in self.inventory]
        save_inventory(inventory_data)