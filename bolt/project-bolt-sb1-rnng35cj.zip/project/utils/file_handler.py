import json
import os

def load_inventory():
    if not os.path.exists('data/inventory.json'):
        return []
    
    with open('data/inventory.json', 'r') as file:
        try:
            return json.load(file)
        except json.JSONDecodeError:
            return []

def save_inventory(inventory):
    os.makedirs('data', exist_ok=True)
    with open('data/inventory.json', 'w') as file:
        json.dump(inventory, file, indent=4)