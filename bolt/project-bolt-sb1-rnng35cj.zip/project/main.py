from services.inventory_manager import InventoryManager

def print_menu():
    print("\n=== Inventory Control System ===")
    print("1. Add new product")
    print("2. Register sale")
    print("3. List all products")
    print("4. Exit")
    print("============================")

def main():
    inventory_manager = InventoryManager()
    
    while True:
        print_menu()
        choice = input("Choose an option (1-4): ")
        
        if choice == "1":
            name = input("Product name: ")
            quantity = int(input("Initial quantity: "))
            price = float(input("Price: "))
            
            product = inventory_manager.add_product(name, quantity, price)
            print(f"\nProduct added successfully! ID: {product.id}")
        
        elif choice == "2":
            product_id = int(input("Product ID: "))
            quantity = int(input("Quantity sold: "))
            
            product = inventory_manager.get_product(product_id)
            if not product:
                print("\nProduct not found!")
                continue
                
            if inventory_manager.update_stock(product_id, quantity):
                print(f"\nSale registered! New stock for {product.name}: {product.quantity}")
            else:
                print(f"\nError: Not enough stock! Available: {product.quantity}")
        
        elif choice == "3":
            products = inventory_manager.list_products()
            print("\nCurrent Inventory:")
            print("ID | Name | Quantity | Price")
            print("-" * 40)
            for product in products:
                print(f"{product.id} | {product.name} | {product.quantity} | ${product.price:.2f}")
        
        elif choice == "4":
            print("\nThank you for using the Inventory Control System!")
            break
        
        else:
            print("\nInvalid option! Please try again.")

if __name__ == "__main__":
    main()